@echo off
call "%~dp0_run.cmd" --crafting
