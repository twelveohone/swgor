@echo off
call "%~dp0_run.cmd" --revert
