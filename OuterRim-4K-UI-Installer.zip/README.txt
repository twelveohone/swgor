OUTER RIM 4K UI
===============

Makes the Outer Rim interface twice the size so it is readable at 3840x2160.
The installer builds the UI from your own Outer Rim install, so it always
matches your current client. Nothing from the game is included in this download.


WHAT YOU NEED
-------------
Nothing extra. The installer carries its own copy of Python in tools\python
(the official portable build from python.org), so you don't need to install
anything.


INSTALL
-------
1. Close the game and the launcher.
2. Copy everything in this download into your Outer Rim game folder,
   the folder that has SwgClient_r.exe. You should end up with a "tools"
   folder and three .bat files next to SwgClient_r.exe.
   (Copy the folder contents, not the zip itself.)
3. Double-click one of these:
     Install 4K UI.bat
     Install 4K UI (with crafter layout).bat
   The crafter layout also enlarges the crafting windows: all experiment
   lines on screen at once, up to ten ingredient slots, and a bigger
   resource stats panel.
4. In the game folder, open options.cfg and set:
     screenWidth=3840
     screenHeight=2160
5. Start the game. After you log in, set the chat font size to 22.

If a crafting window opens at its old size, drag its corner once and the
game remembers the new size.


AFTER AN OUTER RIM UPDATE
-------------------------
Run the same Install file again. It rebuilds the UI from the updated game.


UNINSTALL
---------
Double-click "Remove 4K UI.bat". It removes the 4K files and puts back any
loose UI files you had before installing.


NOTES
-----
- Your group frame style is read from your launcher settings when you
  install. If you change it later, run the installer again.
- Files the installer replaces are moved to ui_scale_backup\previous,
  never deleted.
