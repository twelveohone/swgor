@echo off
setlocal
cd /d "%~dp0"
if not exist "SwgClient_r.exe" if not exist "SWGEmu.exe" (
  echo This folder does not look like an Outer Rim game folder.
  echo Copy these files into the folder that has SwgClient_r.exe, then try again.
  echo.
  pause
  exit /b 1
)
set "PY="
if exist "tools\python\python.exe" set "PY="tools\python\python.exe""
if not defined PY where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo The tools\python folder is missing from this install.
  echo Download the 4K UI installer again and copy all of it into the game folder.
  echo.
  pause
  exit /b 1
)
echo Close the game and the launcher before continuing.
echo.
%PY% tools\scale_ui.py %*
echo.
if errorlevel 1 (echo Something went wrong. The message above says what.) else (echo Done.)
pause
