r"""Build the Outer Rim 4K UI: the game's own interface, scaled 2x for 3840x2160.

Every layout is read from the archives the client loads (swgemu.cfg search
trees, highest priority wins), scaled, and written loose into ui\. Loose files
override the archives, so this is what the client uses.

    python tools/scale_ui.py            build the 4K UI in this game folder
    python tools/scale_ui.py --pack     build it and write OuterRim-4K-UI.zip to share
    python tools/scale_ui.py --crafting add the crafter layout to the crafting windows
    python tools/scale_ui.py --revert   remove it and put back what was there before

Before building, ui\ is cleared. Files from an earlier build are removed, and any
other loose files are moved to ui_scale_backup\previous\ (never deleted), because
a loose layout that does not match this client can crash it.
"""

from __future__ import annotations

import argparse
import re
import shutil
import struct
import sys
import time
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BACKUP = ROOT / "ui_scale_backup"
MANIFEST = BACKUP / "written_files.txt"
MARKER = BACKUP / "BUILD.txt"
PREVIOUS = BACKUP / "previous"
PACK_NAME = "OuterRim-4K-UI.zip"
# Left behind by the first version of this tool.
LEGACY_MARKER = BACKUP / "SCALE_FACTOR.txt"
LEGACY_TRES = BACKUP / "tres"
LEGACY_EXTRA_FILES = ("string/en/ui_charsheet.stf",)
SCALE = 2
SENTINEL = 8192

GROUP_TRES = (
    "or_group_display_classic_v29.tre",
    "or_group_frames_compact_v30.tre",
    "or_group_frames_options_v30.tre",
    "or_group_frames_standard_v30.tre",
)

SKIP_FILES = {
    "ui/ui_fonts.inc",
    "ui/ui_defaultfont.inc",
    "ui/ui_textstylemanager.inc",
}

# Pixel metrics only. PackSize, SourceRect, opacity, angles, and counts are absent
# on purpose: PackSize='1,1' is a fill ratio, and SourceRect is a texture region.
PIXEL_ATTRS = {
    "size",
    "sizex",
    "sizey",
    "minimumsize",
    "minimumsizex",
    "minimumsizey",
    "maximumsize",
    "maximumsizex",
    "maximumsizey",
    "location",
    "locationx",
    "locationy",
    "scrollextent",
    "scrolllocation",
    "minimumscrollextent",
    "scrollsizeline",
    "scrollsizepage",
    "sizeincrement",
    "margin",
    "iconmargin",
    "iconmaxsize",
    "iconminsize",
    "thickness",
    "thicknessouter",
    "spacing",
    "cellpadding",
    "cellheight",
    "cellsize",
    "cellwidth",
    "dropshadowdepth",
    "buttonwidth",
    "buttonheight",
    "dropdownheight",
    "dropdownwidth",
    "scrollbarwidth",
    "scrollbarheight",
    "textpadding",
    "caratwidth",
    "textboxmargin",
    "marginhotspot",
    "buttonlengthend",
    "buttonlengthstart",
    "buttonlengththumb",
    "buttonmargin",
    "buttonmargintrack",
    "buttonmarginthumb",
    "buttonmarginstart",
    "buttonmarginend",
    "buttonmarginoverlay",
    "width",
    "height",
    "indention",
    "indent",
    "itemheight",
    "itemradius",
    "pieinnerradius",
    "runspacing",
    "itemwidth",
    "textoffset",
    "offset",
    "listmargin",
    "marginvalue",
    "disabledtextmargin",
    "mouseovertextmargin",
    "normaltextmargin",
    "selectedtextmargin",
    "pressedtextmargin",
    "scrollbarmargin",
    "startsize",
    "indentation",
    "targetsize",
    "minsize",
    "imagebottomwidth",
    "borderoffsetx",
    "borderoffsety",
    "skinwidth",
    "minimumsizeitem",
    "padding",
    "radartoparentoffset",
    "buttonmargindisabledtrack",
    "itemmargin",
    "maxwidth",
    "doorleftmargin",
    "doorrightmargin",
    "dropby",
    "stopoffset",
}

# Bitmap fonts that actually contain glyphs. Empty TRE entries are masks, not fonts.
FACE_SIZES = {
    "bold": [12, 13, 14, 15, 16, 17, 18, 20, 22, 24],
    "verdana_bold": [12, 13, 14, 15, 16, 17, 18, 20, 22, 24],
    "default": [12, 13, 14, 16, 17, 18, 20, 22],
    "verdana": [12, 13, 14, 16, 17, 18, 20, 22],
    "normal": [12, 13, 14, 16, 17, 18, 20, 22],
    "starwars": [12, 18, 21, 26, 32, 56],
    "fixed": [12, 14],
    "lucida_console": [12, 14],
    "aurabesh": [12, 18, 24],
    "starwarslogo": [12, 18, 21, 26, 32, 56],
    "starwarslogo_optimized": [12, 18, 21, 26, 32, 56],
}

ATTR_RE = re.compile(
    rb"(?i)(?<![A-Za-z0-9_])((?:[A-Za-z0-9_]+\.)*)([A-Za-z][A-Za-z0-9]*)(\s*=\s*)(['\"])([^'\"]*)\4"
)
SOURCE_RECT_RE = re.compile(rb"SourceRect\s*=\s*'[^']*'")
FONT_RE = re.compile(rb"([A-Za-z][A-Za-z0-9]*)_(\d+)")
INT_RE = re.compile(rb"-?\d+")
FLOAT_RE = re.compile(rb"-?\d+\.\d+")

stats = {
    "pixel_values": 0,
    "fonts": 0,
    "files_written": 0,
    "files_unchanged": 0,
}
font_changes: dict[tuple[str, int, int], int] = {}
unmapped_fonts: dict[str, int] = {}
missed_attrs: dict[str, int] = {}


def map_font_size(size: int, available: list[int]) -> int:
    target = size * SCALE
    candidates = [item for item in available if item >= size]
    if not candidates:
        return size
    return min(candidates, key=lambda item: (abs(item - target), item))


def scale_number(token: bytes) -> bytes:
    if INT_RE.fullmatch(token):
        value = int(token)
        if abs(value) >= SENTINEL:
            return token
        return str(value * SCALE).encode()
    if FLOAT_RE.fullmatch(token):
        value = float(token)
        if abs(value) >= SENTINEL:
            return token
        scaled = value * SCALE
        text = f"{scaled:.2f}".rstrip("0").rstrip(".")
        return text.encode()
    return token


def scale_pixel_value(raw: bytes) -> bytes | None:
    parts = raw.split(b",")
    changed = False
    out = []
    for part in parts:
        match = re.search(rb"-?\d+(?:\.\d+)?", part)
        if match is None or match.group(0) != part.strip():
            return None
        token = match.group(0)
        scaled = scale_number(token)
        if scaled != token:
            changed = True
        out.append(part[: match.start()] + scaled + part[match.end() :])
    if not changed:
        return None
    stats["pixel_values"] += 1
    return b",".join(out)


def remap_font(raw: bytes, attr: str) -> bytes | None:
    if attr != "font" and not attr.endswith("textstyle"):
        return None
    match = FONT_RE.fullmatch(raw)
    if match is None:
        return None
    face = match.group(1).decode("ascii").lower()
    size = int(match.group(2))
    available = FACE_SIZES.get(face)
    if available is None:
        unmapped_fonts[raw.decode("ascii", "replace")] = unmapped_fonts.get(raw.decode("ascii", "replace"), 0) + 1
        return None
    new_size = map_font_size(size, available)
    if new_size == size:
        return None
    key = (face, size, new_size)
    font_changes[key] = font_changes.get(key, 0) + 1
    stats["fonts"] += 1
    return match.group(1) + b"_" + str(new_size).encode()


def scale_bytes(data: bytes, rel: str) -> bytes:
    source_rects = SOURCE_RECT_RE.findall(data)

    def replace(match: re.Match[bytes]) -> bytes:
        name = match.group(2).decode("ascii").lower()
        raw = match.group(5)
        updated = None
        if name in PIXEL_ATTRS:
            updated = scale_pixel_value(raw)
        else:
            updated = remap_font(raw, name)
            if updated is None and re.fullmatch(rb"-?\d+(?:\.\d+)?(?:\s*,\s*-?\d+(?:\.\d+)?)*", raw):
                interesting = (
                    "size",
                    "margin",
                    "width",
                    "height",
                    "pad",
                    "offset",
                    "extent",
                    "space",
                    "indent",
                    "cell",
                    "button",
                    "scroll",
                    "thick",
                    "inset",
                    "gap",
                    "border",
                    "drop",
                    "radius",
                )
                if any(piece in name for piece in interesting):
                    missed_attrs[name] = missed_attrs.get(name, 0) + 1
        if updated is None:
            return match.group(0)
        return match.group(1) + match.group(2) + match.group(3) + match.group(4) + updated + match.group(4)

    scaled = ATTR_RE.sub(replace, data)
    if SOURCE_RECT_RE.findall(scaled) != source_rects:
        raise RuntimeError(f"SourceRect changed while scaling {rel}")
    return scaled


def read_header(handle) -> dict:
    handle.seek(0)
    head = handle.read(36)
    if head[:4] != b"EERT" or head[4:8] != b"5000":
        raise ValueError(f"unsupported archive header {head[:8]!r}")
    count, info_off, info_comp, info_csize, name_comp, name_csize, name_usize = struct.unpack_from("<7I", head, 8)
    return {
        "count": count,
        "info_off": info_off,
        "info_comp": info_comp,
        "info_csize": info_csize,
        "name_comp": name_comp,
        "name_csize": name_csize,
        "name_usize": name_usize,
    }


def decompress_block(blob: bytes, method: int, label: str) -> bytes:
    if method == 0:
        return blob
    if method == 2:
        return zlib.decompress(blob)
    raise ValueError(f"unsupported {label} compression {method}")


def load_tre(path: Path, include=None) -> tuple[bytes, list[dict]]:
    """Read an archive. include(name) selects which payloads to load; others are skipped."""
    with path.open("rb") as handle:
        header = read_header(handle)
        handle.seek(header["info_off"])
        info = decompress_block(handle.read(header["info_csize"]), header["info_comp"], "info")
        name = decompress_block(handle.read(header["name_csize"]), header["name_comp"], "name")
        if len(info) != header["count"] * 24:
            raise ValueError(f"{path.name} info block does not match the file count")
        records = []
        for index in range(header["count"]):
            crc, uncomp, offset, compressor, csize, nameoff = struct.unpack_from("<6I", info, index * 24)
            end = name.find(b"\x00", nameoff)
            record_name = name[nameoff:end].decode("latin1")
            if include is not None and not include(record_name.replace("\\", "/")):
                continue
            handle.seek(offset)
            payload = handle.read(csize if compressor else uncomp)
            if compressor == 2:
                payload = zlib.decompress(payload)
            elif compressor != 0:
                raise ValueError(f"unsupported file compression {compressor} in {path.name}:{record_name}")
            records.append(
                {
                    "name": record_name,
                    "crc": crc,
                    "nameoff": nameoff,
                    "payload": payload,
                }
            )
    return name, records


def write_tre(path: Path, name_blob: bytes, records: list[dict]) -> None:
    offset = 36
    info = bytearray()
    chunks = []
    for record in records:
        payload = record["payload"]
        info += struct.pack("<6I", record["crc"], len(payload), offset, 0, len(payload), record["nameoff"])
        chunks.append(payload)
        offset += len(payload)
    info_c = zlib.compress(bytes(info))
    name_c = zlib.compress(name_blob)
    header = b"EERT" + b"5000" + struct.pack("<7I", len(records), offset, 2, len(info_c), 2, len(name_c), len(name_blob))
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("wb") as handle:
        handle.write(header)
        for chunk in chunks:
            handle.write(chunk)
        handle.write(info_c)
        handle.write(name_c)
    temp.replace(path)


def search_trees() -> list[str]:
    """Archives named in the client config, lowest priority first.

    The client lets a higher searchTree number win, so later entries in the
    returned list override earlier ones when layouts are collected.
    """
    found: dict[str, int] = {}

    def walk(path: Path) -> None:
        text = path.read_text(encoding="latin1", errors="replace")
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.lower().startswith(".include"):
                match = re.search(r'"([^"]+)"', stripped)
                if match:
                    included = (path.parent / match.group(1)).resolve()
                    if included.exists():
                        walk(included)
                continue
            match = re.match(r"searchTree_(\d+)_(\d+)\s*=\s*\"?([^\"]+?)\"?\s*$", stripped)
            if match:
                priority = int(match.group(1)) * 1000 + int(match.group(2))
                filename = match.group(3).strip()
                found[filename] = max(priority, found.get(filename, -1))

    walk(ROOT / "swgemu.cfg")
    return [name for name, _priority in sorted(found.items(), key=lambda item: item[1])]


def is_layout_file(name: str) -> bool:
    lowered = name.lower().replace("\\", "/")
    if not lowered.startswith("ui/"):
        return False
    if "/font/" in lowered or lowered in SKIP_FILES:
        return False
    return lowered.endswith(".inc") or lowered.endswith(".ui")


def active_group_tre() -> str:
    """The group-frame archive the player picked in Options > Interface."""
    cfg = ROOT / "or_group_display.cfg"
    if cfg.exists():
        for line in cfg.read_text(encoding="latin1", errors="replace").splitlines():
            match = re.match(r"\s*searchTree_\d+_\d+\s*=\s*\"?([^\"\s]+)", line)
            if match and match.group(1) in GROUP_TRES and (ROOT / match.group(1)).exists():
                return match.group(1)
    return GROUP_TRES[0]


def group_names_from(path: Path) -> set[str]:
    _name, records = load_tre(path)
    return {record["name"].replace("\\", "/") for record in records if is_layout_file(record["name"])}


def collect_archive_layouts(group_names: set[str]) -> dict[str, bytes]:
    """Every UI layout as the client would load it from Outer Rim's own archives."""
    layouts: dict[str, bytes] = {}
    print("reading UI from archives")
    for filename in search_trees():
        if filename in GROUP_TRES:
            continue
        path = ROOT / filename
        if not path.exists():
            continue
        try:
            _name, records = load_tre(path, include=is_layout_file)
        except ValueError as exc:
            print(f"  skip {filename}: {exc}")
            continue
        added = 0
        for record in records:
            rel = record["name"].replace("\\", "/")
            if is_layout_file(rel) and rel not in group_names:
                layouts[rel] = record["payload"]
                added += 1
        if added:
            print(f"  {filename}: {added} layout files")
    return layouts


# --- crafting layout (optional, --crafting) ------------------------------------
#
# Re-lays out the crafting windows so more fits on screen. Widgets are only
# resized and moved. No widget is added, removed or renamed, so every CodeData
# path the client looks up still resolves.
#
# Resizing follows the client's own packing rules (PackSize / PackLocation),
# the same rules it applies when a player drags a window corner, so child
# panels stay where the original designers anchored them.

TAG_RE = re.compile(
    rb"<(/?)([A-Za-z_][\w.]*)((?:\s+[^\s=/>]+\s*=\s*'(?:[^'\\]|\\.)*')*)\s*(/?)>"
)
ATTR_PAIR_RE = re.compile(rb"([^\s=/>]+)(\s*=\s*)'((?:[^'\\]|\\.)*)'")


class Node:
    __slots__ = ("tag", "attrs", "start", "end", "children", "parent", "edits")

    def __init__(self, tag, attrs, start, end, parent):
        self.tag = tag
        self.attrs = attrs
        self.start = start
        self.end = end
        self.children = []
        self.parent = parent
        self.edits = {}

    def get(self, key, default=None):
        lowered = key.lower()
        if lowered in self.edits:
            return self.edits[lowered][1]
        for name, value in self.attrs.items():
            if name.lower() == lowered:
                return value
        return default

    def set(self, key, value):
        original = next((name for name in self.attrs if name.lower() == key.lower()), key)
        self.edits[key.lower()] = (original, value)

    @property
    def name(self):
        return self.get("Name", "")


def parse_layout(data: bytes) -> Node:
    root = Node("__root__", {}, 0, 0, None)
    current = root
    for match in TAG_RE.finditer(data):
        if match.start() > 0 and data[match.start() - 1 : match.start()] == b"\\":
            continue
        closing, tag, raw_attrs, self_closing = match.groups()
        tag = tag.decode("latin1")
        if closing:
            node = current
            while node is not root and node.tag != tag:
                node = node.parent
            if node is not root:
                current = node.parent
            continue
        attrs = {
            key.decode("latin1"): value.decode("latin1")
            for key, _eq, value in ATTR_PAIR_RE.findall(raw_attrs)
        }
        node = Node(tag, attrs, match.start(), match.end(), current)
        current.children.append(node)
        if not self_closing:
            current = node
    return root


def write_layout(data: bytes, root: Node) -> bytes:
    edits = []

    def collect(node):
        if node.edits:
            edits.append(node)
        for child in node.children:
            collect(child)

    collect(root)
    out = bytearray(data)
    for node in sorted(edits, key=lambda item: item.start, reverse=True):
        tag_bytes = bytes(out[node.start : node.end])
        for _lowered, (key, value) in node.edits.items():
            encoded = value.encode("latin1")
            pattern = re.compile(rb"(\s)(" + re.escape(key.encode("latin1")) + rb")(\s*=\s*)'(?:[^'\\]|\\.)*'", re.I)
            if pattern.search(tag_bytes):
                tag_bytes = pattern.sub(lambda m: m.group(1) + m.group(2) + m.group(3) + b"'" + encoded + b"'", tag_bytes, count=1)
            else:
                insert_at = len(tag_bytes) - (2 if tag_bytes.endswith(b"/>") else 1)
                tag_bytes = tag_bytes[:insert_at].rstrip() + b" " + key.encode("latin1") + b"='" + encoded + b"'" + tag_bytes[insert_at:]
        out[node.start : node.end] = tag_bytes
    return bytes(out)


def find(root: Node, path: str) -> list[Node]:
    """Nodes matching a dotted Name path. '*' matches any one name."""
    parts = path.split(".")
    found = []

    def walk(node, depth):
        for child in node.children:
            if child.tag == "Data":
                continue
            name = child.name
            if not name:
                continue
            if parts[depth] == "*" or name.lower() == parts[depth].lower():
                if depth == len(parts) - 1:
                    found.append(child)
                else:
                    walk(child, depth + 1)

    walk(root, 0)
    if not found:
        raise RuntimeError(f"crafting layout: no widget at {path}")
    return found


def _pair(text, default=(0, 0)):
    if text is None:
        return default
    nums = [int(round(float(part))) for part in text.split(",") if part.strip()]
    if len(nums) == 1:
        return (nums[0], nums[0])
    return (nums[0], nums[1]) if len(nums) >= 2 else default


def _codes(text, default):
    if not text:
        return (default, default)
    parts = [part.strip().lower() for part in text.split(",")]
    # A single code covers the horizontal axis only.
    return (parts[0], parts[1] if len(parts) > 1 else default)


def _clamp(value, low, high):
    if low is not None:
        value = max(value, low)
    if high is not None:
        value = min(value, high)
    return value


def resize(node: Node, new_w: int, new_h: int) -> None:
    """Set a widget's size and re-pack its children like the client does."""
    old_w, old_h = _pair(node.get("Size"))
    node.set("Size", f"{new_w},{new_h}")
    if node.get("ScrollExtent") is not None:
        ext_w, ext_h = _pair(node.get("ScrollExtent"))
        node.set("ScrollExtent", f"{max(ext_w, new_w)},{max(ext_h, new_h)}")
    if (old_w, old_h) == (new_w, new_h) or node.tag in ("VolumePage", "Runner"):
        return
    for child in node.children:
        if child.tag == "Data" or child.get("Size") is None:
            continue
        repack_child(child, (old_w, old_h), (new_w, new_h))


def repack_child(child: Node, old_parent, new_parent) -> None:
    size_codes = _codes(child.get("PackSize"), "f")
    loc_codes = _codes(child.get("PackLocation"), "nfn")
    old_size = _pair(child.get("Size"))
    old_loc = _pair(child.get("Location"))
    min_size = _pair(child.get("MinimumSize"), (None, None))
    max_size = _pair(child.get("MaximumSize"), (None, None))
    new_size = []
    new_loc = []
    for axis in (0, 1):
        delta = new_parent[axis] - old_parent[axis]
        code = size_codes[axis][:1]
        size = old_size[axis]
        if code == "a":
            size = size + delta
        elif code == "h":
            size = size + delta // 2
        elif code == "p" and old_parent[axis]:
            size = round(size * new_parent[axis] / old_parent[axis])
        size = _clamp(size, min_size[axis], max_size[axis])
        grown = size - old_size[axis]
        lcode = loc_codes[axis]
        anchor = lcode[:1]
        middle = lcode[1:2]
        x = old_loc[axis]
        if anchor == "c":
            x = x + (delta - grown) // 2
        elif middle == "p" and old_parent[axis]:
            x = round(x * new_parent[axis] / old_parent[axis])
        elif anchor == "f":
            x = x + delta - grown
        new_size.append(size)
        new_loc.append(x)
    if tuple(new_loc) != old_loc:
        child.set("Location", f"{new_loc[0]},{new_loc[1]}")
    if tuple(new_size) != old_size:
        resize(child, new_size[0], new_size[1])


def grow(node: Node, dw: int, dh: int) -> None:
    width, height = _pair(node.get("Size"))
    resize(node, width + dw, height + dh)


def s(value: int) -> int:
    """Design values below are at 1x; the build runs at SCALE."""
    return value * SCALE


def layout_experiment(root: Node) -> None:
    window = find(root, "experiment")[0]
    # Extra height goes to the experiment lines instead of the item preview,
    # so a full schematic's lines show without scrolling.
    find(root, "experiment.Info")[0].set("PackSize", "a,f")
    find(root, "experiment.exp")[0].set("PackSize", "a,a")
    grow(window, 0, s(235))


def layout_assembly(root: Node) -> None:
    window = find(root, "assembly")[0]
    # Smaller slot tiles so more ingredient slots fit before scrolling.
    volume = find(root, "assembly.newcomp.volume")[0]
    cell_w, _cell_h = _pair(volume.get("CellSize"))
    volume.set("CellSize", f"{cell_w},{s(96)}")
    pad_x, pad_y = _pair(volume.get("CellPadding"))
    columns = _pair(volume.get("CellCount"))[0] or 1
    for index, cell in enumerate(find(root, "assembly.newcomp.volume.p")):
        row, column = divmod(index, columns)
        cell.set("Location", f"{column * (cell_w + pad_x)},{pad_y + row * (s(96) + pad_y)}")
        cell.set("Size", f"{cell_w},{s(96)}")
        cell.set("MinimumSize", f"{cell_w},{s(96)}")
        cell.set("MaximumSize", f"{cell_w},{s(96)}")
        cell.set("ScrollExtent", f"{cell_w},{s(96)}")
    for icon in find(root, "assembly.newcomp.volume.p.line"):
        icon.set("Size", f"{s(57)},{s(57)}")
        icon.set("MinimumSize", f"{s(57)},{s(57)}")
        icon.set("MaximumSize", f"{s(57)},{s(57)}")
        icon.set("Location", f"{s(34)},{s(39)}")
    for bar in find(root, "assembly.newcomp.volume.p.qualityBar"):
        bar.set("Size", f"{s(7)},{s(53)}")
        bar.set("Location", f"{s(108)},{s(41)}")
    # The selected resource's stats get the room: the hopper list keeps its
    # height and the stats panel under it takes all of the extra height.
    # Extra width goes to the hopper side so resource stats wrap less; the
    # slot grid has a fixed width and just slides right.
    find(root, "assembly.hopper")[0].set("PackSize", "a,a")
    find(root, "assembly.newcomp")[0].set("PackSize", "f,a")
    find(root, "assembly.hopper.target")[0].set("PackSize", "a,f")
    info = find(root, "assembly.hopper.Info")[0]
    info.set("PackSize", "a,a")
    find(root, "assembly.hopper.Info.content.textAttribs")[0].set("PackSize", "a,f")
    grow(window, s(100), s(150))
    attribs = find(root, "assembly.hopper.Info.content.textAttribs")[0]
    content = find(root, "assembly.hopper.Info.content")[0]
    _cw, content_h = _pair(content.get("Size"))
    attr_w, attr_h = _pair(attribs.get("Size"))
    extra = s(150)
    attribs.set("Size", f"{attr_w},{attr_h + extra}")
    desc = find(root, "assembly.hopper.Info.content.textDesc")[0]
    dx, dy = _pair(desc.get("Location"))
    desc.set("Location", f"{dx},{dy + extra}")


LARGE_FONTS = ("ui/font/verdana_30.inc", "ui/font/verdana_bold_30.inc")
LARGE_FONTS_OK = False


def layout_survey(root: Node) -> None:
    window = find(root, "Surveying")[0]
    # Extra width goes to the resource tree so long names fit; the map keeps
    # its size and position.
    find(root, "Surveying.menu.window.Locations")[0].set("PackSize", "f,f")
    grow(window, s(100), s(75))
    if LARGE_FONTS_OK:
        _bump_fonts(root, {"bold_24": "bold_30"})


def layout_styles(root: Node) -> None:
    if not LARGE_FONTS_OK:
        raise RuntimeError("30 point fonts not available, tree lists keep their size")
    # Tree lists: survey resource tree, crafting schematic list, skills, quests.
    tree = find(root, "Styles.tree.style")[0]
    tree.set("DefaultTextStyle", "default_30")
    tree.set("CellHeight", str(s(23)))


def _bump_fonts(root: Node, mapping: dict[str, str]) -> None:
    def walk(node):
        for child in node.children:
            for key in ("Font", "TextStyle"):
                value = child.get(key)
                if value and value.lower() in mapping:
                    child.set(key, mapping[value.lower()])
            walk(child)

    walk(root)


def fix_space_flyout(root: Node) -> None:
    """Ship component flyout: space the component icons so each status line fits.

    Each icon gets a status popout the height of 'sample'. At 2x the icons sat
    closer together than one popout is tall, so the lines overlapped.
    """
    sample = find(root, "HudSpace.FlyAway.sample")[0]
    volume = find(root, "HudSpace.FlyAway.components.vs")[0]
    _sw, sample_h = _pair(sample.get("Size"))
    _cw, cell_h = _pair(volume.get("CellSize"))
    pad_x, pad_y = _pair(volume.get("CellPadding"))
    step = max(cell_h + pad_y, sample_h)
    pad_y = step - cell_h
    buttons = find(root, "HudSpace.FlyAway.components.vs.*")
    height = pad_y + step * len(buttons)
    volume.set("CellPadding", f"{pad_x},{pad_y}")
    min_w, _min_h = _pair(volume.get("MinimumScrollExtent"))
    volume.set("MinimumScrollExtent", f"{min_w},{height - pad_y}")
    for index, button in enumerate(buttons):
        x, _y = _pair(button.get("Location"))
        button.set("Location", f"{x},{pad_y + index * step}")
    for path in ("HudSpace.FlyAway", "HudSpace.FlyAway.components", "HudSpace.FlyAway.components.vs"):
        node = find(root, path)[0]
        width, _h = _pair(node.get("Size"))
        node.set("Size", f"{width},{height}")
        node.set("ScrollExtent", f"{width},{height}")
        for key in ("MinimumSize", "MaximumSize"):
            if node.get(key) is not None:
                kw, _kh = _pair(node.get(key))
                node.set(key, f"{kw},{height}")


def fix_login_text(root: Node) -> None:
    """Login boxes type in lucida_console_14, the largest fixed font the client
    has, which is tiny at 2x. Use the 22 point face the rest of the UI already
    draws with."""
    for style in find(root, "Styles.textbox.login.*"):
        if style.tag == "TextboxStyle" and (style.get("NormalTextStyle") or "").lower() == "fixed_14":
            style.set("NormalTextStyle", "default_22")


# Survey map numbers: the client's bold face stops at 24. Install the base
# game's 30 point bold under new file and texture names (Outer Rim's archives
# block the original names) and point only the survey map at it.
SURVEY_FONT_INC = "ui/font/or4k_bold_30.inc"
SURVEY_FONT_TEX = "texture/font/or4k_bold_30_000.dds"
SURVEY_FONT_OK = False


def prepare_survey_font() -> dict[str, bytes]:
    found = best_copies({"ui/font/verdana_bold_30.inc", "texture/font/verdana_bold_30_000.dds"})
    inc = found.get("ui/font/verdana_bold_30.inc")
    tex = found.get("texture/font/verdana_bold_30_000.dds")
    if not inc or not tex or b"<FontCharacter" not in inc:
        print("note: 30 point bold font not found in the archives; survey numbers stay at 24")
        return {}
    pages = set(re.findall(rb"SourceFile='([^']+)'", inc))
    if pages != {b"font/verdana_bold_30_000"}:
        print("note: 30 point bold font uses unexpected texture pages; survey numbers stay at 24")
        return {}
    inc = inc.replace(b"SourceFile='font/verdana_bold_30_000'", b"SourceFile='font/or4k_bold_30_000'")
    return {SURVEY_FONT_INC: inc, SURVEY_FONT_TEX: tex}


def fix_survey_numbers(root: Node) -> None:
    if not SURVEY_FONT_OK:
        raise RuntimeError("survey font not installed")
    find(root, "Surveying.menu.window.Locations.MapWidget")[0].set("TextStyle", "bold_30")
    for text in find(root, "Surveying.menu.window.Locations.sample.text"):
        text.set("Font", "bold_30")


# Corrections to the plain 2x build, applied to every build.
FIXUPS = {
    "ui/ui_hud_space.inc": fix_space_flyout,
    "ui/ui_styles.inc": fix_login_text,
}


def apply_fixups(rel: str, data: bytes) -> bytes:
    handler = FIXUPS.get(rel)
    if handler is None:
        return data
    root = parse_layout(data)
    before = _names(root)
    try:
        handler(root)
    except RuntimeError as exc:
        print(f"warning: {exc}; {rel} keeps the plain 4K layout")
        return data
    result = write_layout(data, root)
    if _names(parse_layout(result)) != before:
        raise RuntimeError(f"fixup changed the widget tree in {rel}")
    print(f"fixed: {rel}")
    return result


CRAFTING_LAYOUTS = {
    "ui/ui_craft_experiment.inc": layout_experiment,
    "ui/ui_craft_assembly.inc": layout_assembly,
    "ui/ui_res_survey.inc": layout_survey,
}


def archive_names() -> set[str]:
    names: set[str] = set()
    for filename in search_trees():
        path = ROOT / filename
        if not path.exists():
            continue
        try:
            blob, _records = load_tre(path, include=lambda name: False)
        except ValueError:
            continue
        names.update(part.decode("latin1").replace("\\", "/").lower() for part in blob.split(b"\0") if part)
    return names


LARGE_FONT_FILES: dict[str, bytes] = {}


def best_copies(wanted: set[str]) -> dict[str, bytes]:
    """Highest-priority non-empty copy of each wanted archive file."""
    found: dict[str, bytes] = {}
    for filename in search_trees():
        path = ROOT / filename
        if not path.exists():
            continue
        try:
            _blob, records = load_tre(path, include=lambda name: name.replace("\\", "/").lower() in wanted)
        except ValueError:
            continue
        for record in records:
            if record["payload"]:
                found[record["name"].replace("\\", "/").lower()] = record["payload"]
    return found


def check_large_fonts() -> bool:
    """Collect the 30 point fonts and their glyph textures so they can ship loose.

    Outer Rim's archives can hide base-game files, so being listed in an archive
    is not enough: the font definitions and every texture they draw from are
    copied out and installed as loose files, which the client always finds.
    """
    LARGE_FONT_FILES.clear()
    fonts = best_copies(set(LARGE_FONTS))
    if set(fonts) != set(LARGE_FONTS) or not all(b"<FontCharacter" in data for data in fonts.values()):
        print("note: 30 point fonts not found in the archives; crafting text stays at 24")
        return False
    sources = set()
    for data in fonts.values():
        sources.update(m.decode("latin1").lower() for m in re.findall(rb"SourceFile='([^']+)'", data))
    textures = {f"texture/{src}.dds" for src in sources}
    found = best_copies(textures)
    missing = sorted(textures - set(found))
    if missing or not textures:
        print(f"note: 30 point font textures missing ({', '.join(missing[:3]) or 'none found'}); crafting text stays at 24")
        return False
    LARGE_FONT_FILES.update(fonts)
    LARGE_FONT_FILES.update(found)
    print(f"30 point fonts found; installing {len(LARGE_FONT_FILES)} font files loose")
    return True


def install_large_fonts() -> None:
    for rel, data in sorted(LARGE_FONT_FILES.items()):
        record_write(rel, data)


def apply_crafting_layout(rel: str, data: bytes) -> bytes:
    handler = CRAFTING_LAYOUTS.get(rel)
    if handler is None:
        return data
    root = parse_layout(data)
    before = _names(root)
    handler(root)
    result = write_layout(data, root)
    after = _names(parse_layout(result))
    if before != after:
        raise RuntimeError(f"crafting layout changed the widget tree in {rel}")
    return result


def _names(root: Node) -> list[tuple[str, str, int]]:
    out = []

    def walk(node, depth):
        for child in node.children:
            out.append((child.tag, child.name, depth))
            walk(child, depth + 1)

    walk(root, 0)
    return out


# --- build state -------------------------------------------------------------

written: list[str] = []
crafted: list[str] = []
CRAFTING = False


def record_write(rel: str, data: bytes) -> None:
    destination = ROOT / rel
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    if rel not in written:
        written.append(rel)


def read_manifest() -> list[str]:
    if not MANIFEST.exists():
        return []
    return [line for line in MANIFEST.read_text(encoding="ascii").splitlines() if line]


def move_aside(rel: str, destination_root: Path) -> None:
    source = ROOT / rel
    target = destination_root / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        target.unlink()
    shutil.move(str(source), str(target))


def loose_ui_files() -> list[str]:
    folder = ROOT / "ui"
    if not folder.exists():
        return []
    return sorted(
        path.relative_to(ROOT).as_posix()
        for path in folder.rglob("*")
        if path.is_file()
    )


def restore_group_archives() -> None:
    """Undo the archive edits made by the first version of this tool."""
    restored = 0
    for name in GROUP_TRES:
        original = LEGACY_TRES / name
        if original.exists() and (ROOT / name).exists():
            if original.read_bytes() != (ROOT / name).read_bytes():
                shutil.copy2(original, ROOT / name)
                restored += 1
    if restored:
        print(f"restored {restored} group archives to their shipped versions")


def prepare_clean_folder() -> None:
    """Clear ui\\ so nothing but this build's output is loaded.

    Files this tool wrote last time are removed. Anything else found in ui\\
    (another mod, hand edits, copies from a different client) is moved into
    ui_scale_backup\\previous\\ rather than deleted, so --revert can put it back.
    """
    BACKUP.mkdir(exist_ok=True)
    ours = set(read_manifest())
    for rel in ours:
        path = ROOT / rel
        if path.exists():
            path.unlink()
    foreign = [rel for rel in loose_ui_files() if rel not in ours]
    for rel in LEGACY_EXTRA_FILES:
        if (ROOT / rel).exists() and LEGACY_MARKER.exists():
            foreign.append(rel)
    if foreign:
        if PREVIOUS.exists() and any(PREVIOUS.rglob("*")):
            target = BACKUP / f"previous_{time.strftime('%Y%m%d_%H%M%S')}"
        else:
            target = PREVIOUS
        for rel in foreign:
            move_aside(rel, target)
        print(f"moved {len(foreign)} loose files that were not from this build into {target.relative_to(ROOT)}")
    restore_group_archives()


def build_loose_layouts(group_names: set[str], group_tre: str) -> None:
    layouts = collect_archive_layouts(group_names)
    unchanged = 0
    for rel, payload in sorted(layouts.items()):
        scaled = scale_bytes(payload, rel)
        scaled = apply_fixups(rel, scaled)
        if CRAFTING and rel in CRAFTING_LAYOUTS:
            try:
                scaled = apply_crafting_layout(rel, scaled)
                crafted.append(rel)
            except RuntimeError as exc:
                print(f"warning: {exc}; {rel} keeps the plain 4K layout")
        if scaled == payload:
            unchanged += 1
            continue
        record_write(rel, scaled)
    print(f"archive layouts: wrote {len(written)} scaled files, {unchanged} needed no change")
    if CRAFTING:
        print(f"crafting layout applied to: {', '.join(crafted) or 'nothing'}")

    # The launcher swaps the group archives back on startup, so the group-frame
    # layouts are published loose too. Loose files win over every archive.
    _name, records = load_tre(ROOT / group_tre)
    group_written = []
    for record in records:
        rel = record["name"].replace("\\", "/")
        if is_layout_file(rel):
            record_write(rel, scale_bytes(record["payload"], rel))
            group_written.append(rel)
    print(f"group layouts from {group_tre}: {', '.join(group_written)}")


# The client draws some text in code with fixed font names instead of layout
# files: inventory and container icon labels use default_12, stack counts use
# default_16. After the 2x build no layout uses those regular-weight sizes, so
# they can be pointed at larger glyphs without changing anything else.
# Icon labels and stack counts are drawn in code with default_12 (verdana_12).
# Point that name at the client's own 22 point font file, the same glyphs and
# texture the rest of the 2x UI draws with. Only the style name changes. This
# matches the fix used on the SWG Uprising client. (Borrowing a base-game font
# whose glyph layout differs from the client's texture garbles the text.)
FONT_ALIASES = {
    "ui/font/verdana_12.inc": "ui/font/verdana_22.inc",
}


def alias_hardcoded_fonts() -> None:
    wanted = set(FONT_ALIASES.values())
    found: dict[str, bytes] = {}
    for filename in search_trees():
        path = ROOT / filename
        if filename in GROUP_TRES or not path.exists():
            continue
        try:
            _name, records = load_tre(path, include=lambda name: name.replace("\\", "/").lower() in wanted)
        except ValueError:
            continue
        for record in records:
            # Some archives carry empty placeholder font files; keep the
            # highest-priority copy that actually has glyphs.
            if b"<FontCharacter" in record["payload"]:
                found[record["name"].replace("\\", "/").lower()] = record["payload"]
    used = re.compile(rb"(?:Font|TextStyle\w*)\s*=\s*'(?:default|normal|verdana)_(\d+)'", re.I)
    in_use = set()
    for rel in written:
        if rel.endswith((".inc", ".ui")) and "/font/" not in rel:
            in_use.update(int(size) for size in used.findall((ROOT / rel).read_bytes()))
    for target, source in FONT_ALIASES.items():
        size = int(re.search(r"_(\d+)\.inc$", target).group(1))
        if size in in_use:
            print(f"warning: layouts still use size {size}; leaving {target} alone")
            continue
        if source not in found:
            print(f"warning: {source} not in the archives; skipping that font")
            continue
        data = found[source]
        old_name = re.search(rb"<TextStyle\b[^>]*\bName='([^']+)'", data)
        if not old_name:
            print(f"warning: could not read the style name in {source}; skipping")
            continue
        own_texture = b"SourceFile='font/" + old_name.group(1) + b"_000'"
        if own_texture not in data:
            print(f"warning: {source} does not draw from its own texture; skipping")
            continue
        # The style name is the file name (font/verdana_12.inc holds verdana_12).
        new_name = target.rsplit("/", 1)[-1][: -len(".inc")].encode("ascii")
        data = data.replace(b"Name='" + old_name.group(1) + b"'", b"Name='" + new_name + b"'", 1)
        record_write(target, data)
        print(f"icon text: {new_name.decode()} now draws with {old_name.group(1).decode()} glyphs")


STARWARS_FONTS = (
    b"font/starwarslogo_optimized_12.inc",
    b"font/starwarslogo_optimized_18.inc",
    b"font/starwarslogo_optimized_21.inc",
    b"font/starwarslogo_optimized_26.inc",
    b"font/starwarslogo_optimized_32.inc",
    b"font/starwarslogo_optimized_56.inc",
)


def patch_text_style_manager() -> None:
    """Teach the font loader the normal and starwars faces used by the layouts."""
    data = None
    for filename in search_trees():
        path = ROOT / filename
        if filename in GROUP_TRES or not path.exists():
            continue
        try:
            _name, records = load_tre(
                path, include=lambda name: name.replace("\\", "/").lower() == "ui/ui_textstylemanager.inc"
            )
        except ValueError:
            continue
        if records:
            data = records[0]["payload"]
    if data is None:
        raise RuntimeError("ui/ui_textstylemanager.inc was not found in any archive")
    if b"FontFaces='default,bold,fixed,aurabesh'" not in data:
        raise RuntimeError("text style manager did not have the expected face list")
    data = data.replace(
        b"FontFaces='default,bold,fixed,aurabesh'",
        b"FontFaces='default,bold,fixed,aurabesh,normal,starwars'",
        1,
    )
    defaults = {
        match.group(1): match.group(2)
        for match in re.finditer(rb"FontFaces_([A-Za-z0-9]+)_default='([^']+)'", data)
    }

    def add_locale_faces(match: re.Match[bytes]) -> bytes:
        locale = match.group(2)
        normal = defaults.get(locale, b"verdana")
        indent = match.group(1)
        extra = (
            b"\n"
            + indent
            + b"FontFaces_"
            + locale
            + b"_normal='"
            + normal
            + b"'\n"
            + indent
            + b"FontFaces_"
            + locale
            + b"_starwars='starwarslogo_optimized'"
        )
        return match.group(0) + extra

    data = re.sub(rb"([ \t]*)FontFaces_([A-Za-z0-9]+)_fixed='[^']+'", add_locale_faces, data)

    def add_logo_fonts(match: re.Match[bytes]) -> bytes:
        body = match.group(2)
        if b"starwarslogo_optimized_12.inc" in body:
            return match.group(0)
        sep = b"\r" if b"\r" in body else b"\n"
        if body and not body.endswith((b"\n", b"\r")):
            body += sep
        body += sep.join(STARWARS_FONTS)
        return match.group(1) + body + b"'"

    data = re.sub(rb"(Fonts_[A-Za-z0-9]+=')([^']*)'", add_logo_fonts, data)

    if SURVEY_FONT_OK:
        def add_survey_font(match: re.Match[bytes]) -> bytes:
            body = match.group(2)
            entry = SURVEY_FONT_INC[3:].encode("ascii")
            if entry not in body:
                sep = b"\r" if b"\r" in body else b"\n"
                if body and not body.endswith((b"\n", b"\r")):
                    body += sep
                body += entry
            return match.group(1) + body + b"'"

        data = re.sub(rb"(Fonts_en=')([^']*)'", add_survey_font, data)

    if CRAFTING and LARGE_FONTS_OK:
        def add_large_fonts(match: re.Match[bytes]) -> bytes:
            body = match.group(2)
            sep = b"\r" if b"\r" in body else b"\n"
            for rel in LARGE_FONTS:
                entry = rel[3:].encode("ascii")
                if entry not in body:
                    if body and not body.endswith((b"\n", b"\r")):
                        body += sep
                    body += entry
            return match.group(1) + body + b"'"

        data = re.sub(rb"(Fonts_en=')([^']*)'", add_large_fonts, data)
    if b"FontFaces_en_normal='verdana'" not in data or b"FontFaces_en_starwars='starwarslogo_optimized'" not in data:
        raise RuntimeError("failed to register the normal and starwars font faces")
    record_write("ui/ui_textstylemanager.inc", data)
    print("registered normal and starwars font faces")


def verify_build() -> None:
    hud = (ROOT / "ui" / "ui_ground_hud.inc").read_bytes()
    if b"Size='2048,1536'" not in hud or b"PackSize='1,1'" not in hud:
        raise RuntimeError("ground HUD frame is not the scaled loose copy")
    stray = [rel for rel in loose_ui_files() if rel not in written]
    if stray:
        raise RuntimeError(f"ui\\ still holds files this build did not write: {', '.join(stray[:5])}")
    manager = (ROOT / "ui" / "ui_textstylemanager.inc").read_bytes()
    if b"font/starwarslogo_optimized_32.inc" not in manager:
        raise RuntimeError("logo font was not added to the text style manager")
    warnings = []
    styles_path = ROOT / "ui" / "ui_styles.inc"
    if styles_path.exists():
        styles = styles_path.read_bytes()
        if b"TextStyle='normal_12'" in styles or b"TextStyle='starwars_18'" in styles:
            warnings.append("ui_styles still uses an unscaled normal or starwars font")
    space = ROOT / "ui" / "ui_hud_space.inc"
    if space.exists() and b"SourceRect='0,0,1024,1024'" not in space.read_bytes():
        warnings.append("space HUD source rect looks different from expected")
    for line in warnings:
        print(f"warning: {line}")
    print("build checks passed")


README = """# Outer Rim 4K UI

The Outer Rim interface at double size, for playing at 3840x2160.

Every file in this pack was generated from the UI that ships inside the Outer Rim
client, scaled 2x. Nothing comes from another server's client, so the layouts match
what the Outer Rim game expects.

Built against the Outer Rim client as of {date}. If Outer Rim updates its UI, grab a
newer build of this pack.

## Install

1. Quit the game.
2. Unzip this archive and copy everything in it (the `ui` folder, and the `texture`
   folder if there is one) into your Outer Rim game folder, the one with
   `SwgClient_r.exe`. Let it overwrite files with the same names.
3. In the game folder, open `options.cfg` and set `screenWidth=3840` and
   `screenHeight=2160`.
4. Start the game. After logging in, set the chat font size to 22.

Leave the files loose. Do not pack them into a `.tre`.

{crafting}Group frames use the "{group}" style. Changing the group frame style in
Options > Interface will not take effect while this pack is installed.

## Uninstall

Delete the files listed in `4k_ui_files.txt` from your game folder.
"""

GROUP_LABELS = {
    "or_group_display_classic_v29.tre": "classic",
    "or_group_frames_compact_v30.tre": "compact",
    "or_group_frames_options_v30.tre": "options",
    "or_group_frames_standard_v30.tre": "standard",
}


def pack(group_tre: str) -> None:
    files = read_manifest()
    if not files:
        raise SystemExit("Nothing to pack. Run the build first.")
    destination = ROOT / PACK_NAME
    if destination.exists():
        old = BACKUP / f"{destination.stem}_{time.strftime('%Y%m%d_%H%M%S')}.zip"
        shutil.move(str(destination), str(old))
        print(f"previous pack moved to {old.relative_to(ROOT)}")
    crafting = ""
    notes = {
        "ui/ui_craft_experiment.inc": "- Experimentation: a full schematic's experiment lines show without scrolling.\n",
        "ui/ui_craft_assembly.inc": "- Assembly: up to ten ingredient slots on screen and a larger resource stats panel.\n",
        "ui/ui_res_survey.inc": "- Survey: a wider resource list so long names fit.\n",
        "ui/ui_styles.inc": "- Tree lists (survey resources, crafting schematics, skills) use larger text.\n",
    }
    if crafted:
        crafting = (
            "This build includes the crafter layout:\n\n"
            + "".join(notes[rel] for rel in crafted if rel in notes)
            + "\nIf a crafting window opens at its old size, drag its corner once and the game\n"
            "will remember the new size.\n\n"
        )
    readme = README.format(
        date=time.strftime("%Y-%m-%d"), group=GROUP_LABELS.get(group_tre, group_tre), crafting=crafting
    )
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for rel in files:
            archive.write(ROOT / rel, rel)
        archive.writestr("README.md", readme)
        archive.writestr("4k_ui_files.txt", "\n".join(files) + "\n")
    print(f"wrote {destination.name} with {len(files)} files")


def apply(make_pack: bool) -> None:
    group_tre = active_group_tre()
    group_names = group_names_from(ROOT / group_tre)
    global LARGE_FONTS_OK
    # Disabled: base-game 30 point fonts installed loose did not render in
    # Outer Rim's client (text came out blank). Text stays on the client's own fonts.
    LARGE_FONTS_OK = False
    global SURVEY_FONT_OK
    # Disabled: the client does not load loose texture files, so a font whose
    # glyph texture is not inside Outer Rim's archives draws blank.
    survey_font: dict[str, bytes] = {}
    SURVEY_FONT_OK = False
    prepare_clean_folder()
    for rel, data in survey_font.items():
        record_write(rel, data)
    if survey_font:
        print("survey numbers: 30 point bold installed as or4k_bold_30")
    try:
        build_loose_layouts(group_names, group_tre)
        if LARGE_FONTS_OK:
            install_large_fonts()
        patch_text_style_manager()
        alias_hardcoded_fonts()
    finally:
        # Record whatever was written, even on failure, so a rerun or --revert
        # knows these files came from this tool.
        MANIFEST.write_text("\n".join(written) + ("\n" if written else ""), encoding="ascii")
    MARKER.write_text(
        f"{SCALE}\nBuilt from the Outer Rim archives for a 3840x2160 UI."
        f"{' Crafting layout included.' if CRAFTING else ''} Undo with: python tools/scale_ui.py --revert\n",
        encoding="ascii",
    )
    verify_build()
    print(f"pixel attributes scaled: {stats['pixel_values']}")
    print(f"font styles remapped: {stats['fonts']}")
    if unmapped_fonts:
        print("unmapped font styles:")
        for name, count in sorted(unmapped_fonts.items()):
            print(f"  {name} x{count}")
    if make_pack:
        pack(group_tre)


def revert() -> None:
    files = read_manifest()
    if not files and not PREVIOUS.exists():
        raise SystemExit("No 4K build found, so there is nothing to undo.")
    for rel in files:
        path = ROOT / rel
        if path.exists():
            path.unlink()
    restored = 0
    if PREVIOUS.exists():
        for path in sorted(PREVIOUS.rglob("*")):
            if path.is_file():
                rel = path.relative_to(PREVIOUS)
                target = ROOT / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(path), str(target))
                restored += 1
        shutil.rmtree(PREVIOUS, ignore_errors=True)
    restore_group_archives()
    for path in (MANIFEST, MARKER):
        if path.exists():
            path.unlink()
    print(f"removed {len(files)} 4K files and put back {restored} files that were there before")


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the Outer Rim 4K UI from the game's own archives, or undo it.")
    parser.add_argument("--revert", action="store_true", help="remove the 4K files and put back what was there before")
    parser.add_argument("--pack", action="store_true", help=f"also write {PACK_NAME} for sharing")
    parser.add_argument("--crafting", action="store_true", help="also apply the crafter layout to the crafting windows")
    args = parser.parse_args()
    global CRAFTING
    CRAFTING = args.crafting
    if args.revert:
        revert()
    else:
        apply(args.pack)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
